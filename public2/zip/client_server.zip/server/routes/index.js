const constants = require("./constant");
const express = require("express");
const router = express.Router();

router.post("/ask", async (req, res) => {
  try {
    const question = req.body[constants.question] || ""; // 拿到用户的问题
    console.log("收到问题:", question);

    const prompt = `你是一个中文智能助手，请使用中文回答用户的问题。问题是：${question}`;

    console.log("调用本地模型:", constants.localModelUrl);
    console.log("使用模型:", constants.model);

    const response = await fetch(constants.localModelUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: constants.model,
        prompt: prompt,
        stream: false,
      }),
    });

    if (!response.ok) {
      console.error("模型API错误:", response.status, response.statusText);
      const errorText = await response.text();
      console.error("错误详情:", errorText);
      return res.status(500).json({
        answer: "抱歉，模型服务暂时不可用，请检查 Ollama 是否正在运行。",
      });
    }

    const result = await response.json();
    console.log("模型响应:", result);

    res.json({
      answer: result.response || "抱歉，模型没有返回有效回答。",
    });
  } catch (error) {
    console.error("服务器错误:", error);
    res.status(500).json({
      answer: "服务器内部错误，请稍后重试。",
    });
  }
});

module.exports = router;
