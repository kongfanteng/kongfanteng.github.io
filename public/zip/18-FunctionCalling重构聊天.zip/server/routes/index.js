const constants = require("./constant");
const express = require("express");
const router = express.Router();
const { callLLMStream, callLLM } = require("../utils/LLM");
const { getWeather } = require("../utils/whetherHandler");
const { translate } = require("../utils/translateHandler");

const toolList = require("../utils/tools");

const toolsMap = {
  getWeather,
  translate,
};

// 要支持上下文，背后的原理非常简单：
// 拿一个数组来存储会话的历史记录，之后每一次会将历史会话记录一同发给大模型
/**
 * @type {{role: "user" | "assistant", content: string}[]}
 */
const conversations = []; // 该数组存储会话记录

router.post("/ask", async (req, res) => {
  try {
    const question = req.body[constants.question] || ""; // 拿到用户的问题
    console.log("收到问题:", question);

    // 流式响应
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");

    const messages = [...conversations, { role: "user", content: question }];
    try {
      const response = await callLLM(messages, toolList, (chunk) => {
        res.write(`${JSON.stringify({ response: chunk })}\n`);
      });

      if (response.tool_calls) {
        const toolResults = [];
        for (const toolCall of response.tool_calls) {
          try {
            const functionName = toolCall.function.name;
            const args = JSON.parse(toolCall.function.arguments);
            if (toolsMap[functionName]) {
              try {
                const result = await toolsMap[functionName](args);
                toolResults.push({
                  tool_call_id: toolCall.id,
                  role: "tool",
                  content: result,
                });
              } catch (error) {
                toolResults.push({
                  tool_call_id: toolCall.id,
                  role: "tool",
                  content: `未知工具${error.message}`,
                });
              }
            }
          } catch (error) {
            toolResults.push({
              tool_call_id: toolCall.id,
              role: "tool",
              content: `工具调用失败${functionName}`,
            });
          }
        }

        messages.push(
          {
            role: "assistant",
            content: response.content,
            tool_calls: response.tool_calls,
          },
          ...toolResults
        );
        const finalResponse = await callLLM(messages, toolList, (chunk) => {
          res.write(`${JSON.stringify({ response: chunk })}\n`);
        });
        conversations.push(
          { role: "user", content: question },
          {
            role: "assistant",
            content: response.content,
            tool_calls: response.tool_calls,
          },
          ...toolResults,
          { role: "assistant", content: finalResponse }
        );
      } else {
        conversations.push(
          { role: "user", content: question },
          { role: "assistant", content: response }
        );
      }
      if (conversations.length > 20) {
        conversations.splice(0, conversations.length - 20);
      }
    } catch (error) {
      conversations.push(
        { role: "user", content: question },
        { role: "assistant", content: "LLM调用失败" }
      );
    }

    res.end();
  } catch (error) {
    console.error("服务器错误:", error);
    res.status(500).json({
      answer: "服务器内部错误，请稍后重试。",
    });
  }
});

router.get("/history", (req, res) => {
  res.json({ conversations });
});
router.post("/clear", (req, res) => {
  conversations.length = 0;
  res.json({ message: "会话已清除" });
});

module.exports = router;
