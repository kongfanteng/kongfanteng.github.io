const LLM_ENDPOINT = process.env.LLM_ENDPOINT;
const LLM_MODEL = process.env.LLM_MODEL;
const LLM_TIMEOUT_MS = process.env.LLM_TIMEOUT_MS;
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;

async function fetchWithTimeout(url, options) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LLM_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(timeout);
    return response;
  } catch (error) {
    clearTimeout(timeout);
    if (error.name === "AbortError") {
      throw new Error("模型请求超时");
    }
    throw error;
  }
}

async function callLLM(messages, tools, callback = null) {
  const requestBody = {
    model: LLM_MODEL,
    messages,
    tools,
    stream: true,
  };
  const toolCalls = []; // [{index, id, type, function}]
  const response = await fetchWithTimeout(LLM_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${DEEPSEEK_API_KEY}`,
    },
    body: JSON.stringify(requestBody),
  });
  if (!response?.ok)
    throw new Error(
      `模型请求失败☹️：${response.status} : ${response.statusText}`
    );

  let fullResponse = "";

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8");
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split("\n").filter((line) => line.trim());
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;

      // 移除 "data :" 的前缀
      const jsonStr = line.slice(6);

      // 跳过最后的 [DONE] 标记
      if (jsonStr === "[DONE]") continue;
      try {
        const data = JSON.parse(jsonStr);

        const delta = data.choices?.[0]?.delta;

        if (delta.content) {
          fullResponse += delta.content;
          callback?.(delta.content);
        }
        if (delta.tool_calls) {
          for (const toolCall of delta.tool_calls) {
            const existingCall = toolCalls.find(
              (call) => call.index === toolCall.index
            );
            if (existingCall) {
              if (toolCall.function?.name) {
                existingCall.function.name = toolCall.function.name;
              }
              if (toolCall.function?.arguments) {
                existingCall.function.arguments += toolCall.function.arguments;
              }
            } else {
              toolCalls.push({
                index: toolCall.index,
                id: toolCall.id,
                type: "function",
                function: {
                  name: toolCall.function.name,
                  arguments: toolCall.function.arguments,
                },
              });
            }
          }
        }
      } catch (error) {
        console.error("解析JSON错误:", error.message);
      }
    }
  }

  if (toolCalls.length > 0) {
    return {
      content: fullResponse,
      tool_calls: toolCalls,
    };
  }

  return fullResponse;
}

module.exports = {
  callLLM,
};
