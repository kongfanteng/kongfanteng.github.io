const LLM_ENDPOINT = process.env.LLM_ENDPOINT;
const LLM_MODEL = process.env.LLM_MODEL;
const LLM_TIMEOUT_MS = process.env.LLM_TIMEOUT_MS;
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;

async function fetchWithTimeout(url, options) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LLM_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(timeout);
    return response;
  } catch (error) {
    clearTimeout(timeout);
    if (error.name === "AbortError") {
      throw new Error("模型请求超时");
    }
    throw error;
  }
}

async function callLLM({ prompt, stream = false, callback = null }) {
  const response = await fetchWithTimeout(LLM_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${DEEPSEEK_API_KEY}`,
    },
    body: JSON.stringify({
      model: LLM_MODEL,
      messages: [{ role: "user", content: prompt }],
      stream,
    }),
  });
  if (!response?.ok)
    throw new Error(
      `模型请求失败☹️：${response.status} : ${response.statusText}`
    );
  if (!stream) {
    const data = await response.json();
    return data?.choices[0]?.message?.content || "";
  }

  let fullResponse = "";

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8");
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split("\n").filter((line) => line.trim());
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;

      // 移除 "data :" 的前缀
      const jsonStr = line.slice(6);

      // 跳过最后的 [DONE] 标记
      if (jsonStr === "[DONE]") continue;
      try {
        const data = JSON.parse(jsonStr);
        const chunk = data.choices?.[0]?.delta?.content;
        if (chunk) {
          fullResponse += chunk;
          callback?.(chunk);
        }
      } catch (error) {
        console.error("解析JSON错误:", error.message);
      }
    }
  }
  return fullResponse;
}

module.exports = {
  callLLMStream: (prompt, callback) =>
    callLLM({ prompt, stream: true, callback }),
  callLLM: (prompt) => callLLM({ prompt }),
};
