const constants = require("./constant");
const express = require("express");
const router = express.Router();
const { callLLMStream, callLLM } = require("../utils/LLM");
const { getWeather } = require("../utils/whetherHandler");
const { translate } = require("../utils/translateHandler");

const toolsMap = {
  getWeather,
  translate,
};
const {
  buildFunctionCallPrompt,
  buildAnswerPrompt,
} = require("../utils/promptTemplates");

// 要支持上下文，背后的原理非常简单：
// 拿一个数组来存储会话的历史记录，之后每一次会将历史会话记录一同发给大模型
/**
 * @type {{role: "user" | "assistant", content: string}[]}
 */
const conversations = []; // 该数组存储会话记录

router.post("/ask", async (req, res) => {
  try {
    const question = req.body[constants.question] || ""; // 拿到用户的问题
    console.log("收到问题:", question);

    // 流式响应
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");

    const functionCallPrompt = buildFunctionCallPrompt(question);
    const functionCallResult = (await callLLM(functionCallPrompt)).replace(
      /<think>[\s\S]*?<\/think>/g,
      ""
    );

    let finalResponse = "";
    if (functionCallResult.trim() === "无函数调用") {
      const prompt = [
        "你是一个中文智能助手，请使用中文回答用户的问题。",
        ...conversations.map(
          (conversation) =>
            `${conversation.role === "user" ? "用户" : "助手"}: ${
              conversation.content
            }`
        ),
        `用户的问题是：${question}`,
      ].join("\n");
      finalResponse = await callLLMStream(prompt, (chunk) => {
        res.write(`${JSON.stringify({ response: chunk })}\n`);
      });
    } else {
      try {
        console.log("functionCallResult 原始内容:", functionCallResult);
        console.log("functionCallResult 类型:", typeof functionCallResult);
        console.log("functionCallResult 长度:", functionCallResult.length);

        const toolCalls = JSON.parse(functionCallResult);
        const toolResults = [];
        for (const toolCall of toolCalls) {
          const { function: fn, args } = toolCall;
          if (toolsMap[fn]) {
            try {
              const result = await toolsMap[fn](args);
              toolResults.push({ function: fn, args, result });
            } catch (error) {
              toolResults.push({
                function: fn,
                args,
                result: `工具调用失败: ${error.message}`,
              });
            }
          } else {
            toolResults.push({
              function: fn,
              args,
              result: `工具不存在: ${fn}`,
            });
          }
        }
        console.log("toolResults:", toolResults);
        const answerPrompt = buildAnswerPrompt(question, toolResults);
        finalResponse = await callLLMStream(answerPrompt, (chunk) => {
          const filteredChunk = chunk.replace(/<think>[\s\S]*?<\/think>/g, "");
          res.write(`${JSON.stringify({ response: filteredChunk })}\n`);
        });
      } catch (error) {
        console.error("解析工具的JSON失败:", error);
        console.error("functionCallResult 内容:", functionCallResult);
        // 发送错误信息给客户端
        res.write(
          `${JSON.stringify({ response: "工具调用解析失败，请重试" })}\n`
        );
      }
    }
    // 过滤掉 <think> 标签内容后存储到会话历史
    const cleanResponse = finalResponse.replace(
      /<think>[\s\S]*?<\/think>/g,
      ""
    );
    conversations.push(
      { role: "user", content: question },
      { role: "assistant", content: cleanResponse }
    );
    if (conversations.length > 20) {
      conversations.splice(0, conversations.length - 20);
    }
    res.end();
  } catch (error) {
    console.error("服务器错误:", error);
    res.status(500).json({
      answer: "服务器内部错误，请稍后重试。",
    });
  }
});

router.get("/history", (req, res) => {
  res.json({ conversations });
});
router.post("/clear", (req, res) => {
  conversations.length = 0;
  res.json({ message: "会话已清除" });
});

module.exports = router;
