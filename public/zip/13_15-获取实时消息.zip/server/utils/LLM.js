const LLM_ENDPOINT = process.env.LLM_ENDPOINT;
const LLM_MODEL = process.env.LLM_MODEL;
const LLM_TIMEOUT_MS = process.env.LLM_TIMEOUT_MS;

async function fetchWithTimeout(url, options) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), LLM_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(timeout);
    return response;
  } catch (error) {
    clearTimeout(timeout);
    if (error.name === "AbortError") {
      throw new Error("模型请求超时");
    }
    throw error;
  }
}

async function callLLM({ prompt, stream = false, callback = null }) {
  const response = await fetchWithTimeout(LLM_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: LLM_MODEL,
      prompt: prompt,
      stream,
      temperature: 0.1,
    }),
  });
  if (!response?.ok)
    throw new Error(
      `模型请求失败☹️：${response.status} : ${response.statusText}`
    );
  if (!stream) {
    const data = await response.json();
    return data.response;
  }

  let fullResponse = "";

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8");
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split("\n").filter((line) => line.trim());
    for (const line of lines) {
      try {
        const data = JSON.parse(line);
        if (data.response) {
          fullResponse += data.response;
          callback?.(data.response);
        }
      } catch (error) {
        console.error("解析JSON错误:", error.message);
      }
    }
  }
  return fullResponse;
}

module.exports = {
  callLLMStream: (prompt, callback) =>
    callLLM({ prompt, stream: true, callback }),
  callLLM: (prompt) => callLLM({ prompt }),
};
