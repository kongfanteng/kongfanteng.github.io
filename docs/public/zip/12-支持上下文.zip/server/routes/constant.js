module.exports = {
  question: "question",
  localModelUrl: "http://localhost:11434/api/generate",
  model: "deepseek-r1:1.5b",
};
