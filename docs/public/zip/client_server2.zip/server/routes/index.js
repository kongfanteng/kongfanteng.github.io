const constants = require("./constant");
const express = require("express");
const router = express.Router();

router.post("/ask", async (req, res) => {
  try {
    const question = req.body[constants.question] || ""; // 拿到用户的问题
    console.log("收到问题:", question);

    const prompt = `你是一个中文智能助手，请使用中文回答用户的问题。问题是：${question}`;

    console.log("调用本地模型:", constants.localModelUrl);
    console.log("使用模型:", constants.model);

    const response = await fetch(constants.localModelUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: constants.model,
        prompt: prompt,
        stream: true,
      }),
    });

    // 流式响应
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");

    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split("\n").filter((line) => line.trim());
      for (const line of lines) {
        try {
          const data = JSON.parse(line);
          if (data.response) {
            res.write(`${JSON.stringify({ response: data.response })}\n`);
          }
        } catch (error) {
          console.error("解析JSON错误:", error.message);
        }
      }
    }
    res.end();
  } catch (error) {
    console.error("服务器错误:", error);
    res.status(500).json({
      answer: "服务器内部错误，请稍后重试。",
    });
  }
});

module.exports = router;
